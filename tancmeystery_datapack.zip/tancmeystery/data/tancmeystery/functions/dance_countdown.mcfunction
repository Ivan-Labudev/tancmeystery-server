scoreboard players remove @s dance_timer 1
execute if score @s dance_timer matches ..0 run function tancmeystery:dance_lose
