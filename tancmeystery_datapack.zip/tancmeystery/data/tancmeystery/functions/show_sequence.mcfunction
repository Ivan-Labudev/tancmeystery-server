tellraw @s {"text":"Запомни последовательность:","color":"yellow"}

execute if score @s dance_seq1 matches 0 run tellraw @s {"text":"1. ⬆ Вперёд","color":"white"}
execute if score @s dance_seq1 matches 1 run tellraw @s {"text":"1. ➡ Направо","color":"white"}
execute if score @s dance_seq1 matches 2 run tellraw @s {"text":"1. ⬇ Назад","color":"white"}
execute if score @s dance_seq1 matches 3 run tellraw @s {"text":"1. ⬅ Налево","color":"white"}

execute if score @s dance_seq2 matches 0 run tellraw @s {"text":"2. ⬆ Вперёд","color":"white"}
execute if score @s dance_seq2 matches 1 run tellraw @s {"text":"2. ➡ Направо","color":"white"}
execute if score @s dance_seq2 matches 2 run tellraw @s {"text":"2. ⬇ Назад","color":"white"}
execute if score @s dance_seq2 matches 3 run tellraw @s {"text":"2. ⬅ Налево","color":"white"}

execute if score @s dance_seq3 matches 0 run tellraw @s {"text":"3. ⬆ Вперёд","color":"white"}
execute if score @s dance_seq3 matches 1 run tellraw @s {"text":"3. ➡ Направо","color":"white"}
execute if score @s dance_seq3 matches 2 run tellraw @s {"text":"3. ⬇ Назад","color":"white"}
execute if score @s dance_seq3 matches 3 run tellraw @s {"text":"3. ⬅ Налево","color":"white"}

execute if score @s dance_seq4 matches 0 run tellraw @s {"text":"4. ⬆ Вперёд","color":"white"}
execute if score @s dance_seq4 matches 1 run tellraw @s {"text":"4. ➡ Направо","color":"white"}
execute if score @s dance_seq4 matches 2 run tellraw @s {"text":"4. ⬇ Назад","color":"white"}
execute if score @s dance_seq4 matches 3 run tellraw @s {"text":"4. ⬅ Налево","color":"white"}

execute if score @s dance_seq5 matches 0 run tellraw @s {"text":"5. ⬆ Вперёд","color":"white"}
execute if score @s dance_seq5 matches 1 run tellraw @s {"text":"5. ➡ Направо","color":"white"}
execute if score @s dance_seq5 matches 2 run tellraw @s {"text":"5. ⬇ Назад","color":"white"}
execute if score @s dance_seq5 matches 3 run tellraw @s {"text":"5. ⬅ Налево","color":"white"}

tellraw @s {"text":"Теперь наступай на плитки в этом порядке!","color":"green"}
