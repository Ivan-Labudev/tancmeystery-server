# Регистрация всех objectives. Выполняется автоматически при заходе датапака.
scoreboard objectives add dance_active dummy
scoreboard objectives add dance_step dummy
scoreboard objectives add dance_len dummy
scoreboard objectives add dance_timer dummy
scoreboard objectives add dance_correct dummy
scoreboard objectives add dance_seq1 dummy
scoreboard objectives add dance_seq2 dummy
scoreboard objectives add dance_seq3 dummy
scoreboard objectives add dance_seq4 dummy
scoreboard objectives add dance_seq5 dummy
scoreboard objectives add dance_wins dummy
scoreboard objectives add dance_coins dummy
scoreboard objectives add dance_start trigger
scoreboard objectives add dance_const dummy

scoreboard players set #mod4 dance_const 4

tellraw @a {"text":"[Танцмейстеры] Датапак загружен","color":"aqua"}
