function tancmeystery:welcome
execute as @a[scores={dance_start=1..}] run function tancmeystery:dance_begin
execute as @a[scores={dance_active=1}] run function tancmeystery:dance_countdown
