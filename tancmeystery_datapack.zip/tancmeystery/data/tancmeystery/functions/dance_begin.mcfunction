# Запускается автоматически, когда игрок делает /trigger dance_start
scoreboard players set @s dance_start 0
scoreboard players set @s dance_active 1
scoreboard players set @s dance_step 0
scoreboard players set @s dance_len 5
scoreboard players set @s dance_timer 200

function tancmeystery:generate_sequence

title @s title {"text":"Приготовься!","color":"gold"}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1
function tancmeystery:show_sequence
