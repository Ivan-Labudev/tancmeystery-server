# Псевдослучайные направления 0-3 (0=вверх 1=право 2=вниз 3=лево)
# Основано на gametime + позиции игрока, для 1.20.x без команды /random.
# Достаточно "случайно" для игры-приколюхи, не для криптографии.

execute store result score @s dance_seq1 run time query gametime
scoreboard players operation @s dance_seq1 %= #mod4 dance_const

scoreboard players add @s dance_seq1 3
execute store result score @s dance_seq2 run data get entity @s Pos[0] 1
scoreboard players operation @s dance_seq2 %= #mod4 dance_const

execute store result score @s dance_seq3 run data get entity @s Pos[2] 1
scoreboard players add @s dance_seq3 7
scoreboard players operation @s dance_seq3 %= #mod4 dance_const

execute store result score @s dance_seq4 run time query daytime
scoreboard players add @s dance_seq4 11
scoreboard players operation @s dance_seq4 %= #mod4 dance_const

execute store result score @s dance_seq5 run data get entity @s UUID[0] 1
scoreboard players add @s dance_seq5 5
scoreboard players operation @s dance_seq5 %= #mod4 dance_const
