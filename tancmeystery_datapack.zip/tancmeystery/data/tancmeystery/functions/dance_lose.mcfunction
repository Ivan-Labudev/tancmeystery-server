scoreboard players set @s dance_active 0
effect give @s minecraft:slowness 5 1

title @s title {"text":"❌ Мимо такта!","color":"red","bold":true}
playsound minecraft:entity.villager.no master @s ~ ~ ~ 1 1
tellraw @s {"text":"Попробуй ещё раз: /trigger dance_start","color":"gray"}
