scoreboard players set @s dance_active 0
scoreboard players add @s dance_wins 1

title @s title {"text":"🎉 Победа!","color":"gold","bold":true}
title @s subtitle {"text":"+10 дэнс-коинов","color":"yellow"}
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"gold"},{"text":" показал(а) класс на танцполе! 🕺","color":"green"}]
