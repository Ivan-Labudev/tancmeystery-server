playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
scoreboard players add @s dance_step 1
scoreboard players set @s dance_timer 200

execute if score @s dance_step >= @s dance_len run function tancmeystery:dance_win
