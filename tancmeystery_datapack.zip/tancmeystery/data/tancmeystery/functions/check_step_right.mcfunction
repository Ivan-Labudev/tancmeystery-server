# Плитка "Направо" (направление 1)
scoreboard players set @s dance_correct 0

execute if score @s dance_active matches 1 if score @s dance_step matches 0 if score @s dance_seq1 matches 1 run scoreboard players set @s dance_correct 1
execute if score @s dance_active matches 1 if score @s dance_step matches 1 if score @s dance_seq2 matches 1 run scoreboard players set @s dance_correct 1
execute if score @s dance_active matches 1 if score @s dance_step matches 2 if score @s dance_seq3 matches 1 run scoreboard players set @s dance_correct 1
execute if score @s dance_active matches 1 if score @s dance_step matches 3 if score @s dance_seq4 matches 1 run scoreboard players set @s dance_correct 1
execute if score @s dance_active matches 1 if score @s dance_step matches 4 if score @s dance_seq5 matches 1 run scoreboard players set @s dance_correct 1

execute if score @s dance_active matches 1 if score @s dance_correct matches 1 run function tancmeystery:advance_step
execute if score @s dance_active matches 1 if score @s dance_correct matches 0 run function tancmeystery:dance_lose
