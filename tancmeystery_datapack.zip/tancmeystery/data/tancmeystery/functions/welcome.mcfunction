execute as @a[tag=!tm_welcomed] at @s run title @s title {"text":"Академия Танцмейстеров","color":"aqua","bold":true}
execute as @a[tag=!tm_welcomed] at @s run title @s subtitle {"text":"Добро пожаловать!","color":"gold"}
execute as @a[tag=!tm_welcomed] at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1
execute as @a[tag=!tm_welcomed] at @s run tellraw @a [{"text":"[Танцмейстеры] ","color":"aqua"},{"selector":"@s"},{"text":" присоединился к академии!","color":"gray"}]
execute as @a[tag=!tm_welcomed] at @s run tag @s add tm_welcomed
